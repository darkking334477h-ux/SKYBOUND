# SKYBOUND — Passenger Airliner Flight Simulator

এটি HTML + CSS + JavaScript + Three.js দিয়ে তৈরি একটি Android-ready 3D free-flight game prototype। প্রথম বিমানটি একটি procedural passenger airliner; এটি কোনো বাস্তব airline বা aircraft manufacturer's exact model নয়।

## এই সংস্করণে আছে
- Procedural 3D passenger airliner: fuselage, swept wings, tail, turbofan nacelles, cabin windows, landing gear ও navigation lights
- Island terrain, ocean, runway, terminal, low-poly city, instanced forest ও procedural clouds
- Free flight controls, throttle, pitch, roll, yaw, speed brake
- Chase camera ও cockpit camera toggle
- Altitude, airspeed, heading, throttle, vertical-speed ও FPS HUD
- Performance / Balanced / High graphics preset
- Capacitor Android wrapper ও GitHub Actions debug APK workflow

## ফোনে চালানোর জন্য
এই project source ZIP নিজে APK নয়। প্রথমে Android-এ Termux দিয়ে source পরীক্ষা করতে পারো:

```bash
pkg update -y
pkg install nodejs-lts git unzip -y
termux-setup-storage
```

ZIP-টি Extract করে project folder-এ ঢুকে:

```bash
npm install
npm run dev -- --host 0.0.0.0
```

Termux-এর দেখানো local URL Chrome-এ খোলো। Three.js ও Vite package download করতে internet লাগবে।

## APK তৈরি (PC ছাড়াই)
1. ZIP extract করে GitHub-এ নতুন repository তৈরি করো।
2. এই project-এর সব file repository-তে upload করো; `.github/workflows/android-apk.yml`-ও রাখতে হবে।
3. GitHub repository-র **Actions** tab-এ গিয়ে **Build Android APK** workflow চালাও (অথবা `main` branch-এ push করো)।
4. Workflow সফল হলে Actions run-এর নিচে `SKYBOUND-debug-APK` artifact download করো।
5. ZIP artifact extract করে `app-debug.apk` Android-এ install করো।

## গুরুত্বপূর্ণ সীমাবদ্ধতা
এটি এখনো একটি playable development build, commercial-grade flight simulator নয়। Terrain, city, clouds ও aircraft geometry procedural; satellite imagery, detailed hand-made airports, realistic aerodynamics, weather simulation, traffic, sound pack ও large external asset library এখনো যোগ করা হয়নি। OPPO A53-এর জন্য **PERFORMANCE** বা **BALANCED** preset দিয়ে শুরু করো। 8K rendering এই ফোনের জন্য বাস্তবসম্মত নয়।
